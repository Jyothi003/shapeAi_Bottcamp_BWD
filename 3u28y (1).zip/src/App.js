import React from "react";
import Header from "./Header";
imporr Footer from "./FFooter;
import Note from "./Note";

function App() {
  return (
    <div>
      <Header />
      <Footer />
      <Note />
      </div>
  );
}

export default App;