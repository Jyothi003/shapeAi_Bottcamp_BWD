import React from "react";

function Header() {
  return (
    <h1>shapeAi</h1>
    </header>  
  );
}

export default header;
