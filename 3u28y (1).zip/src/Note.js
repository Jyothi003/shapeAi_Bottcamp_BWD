import React from "react";

function  return ()
return (
  <div classmame="Note";
  <h1>javascript and React.js</h1>
  <pp
  This is the amazing bootcamp taken by shaurya sinha everything including scratch including java.
  </p>
  </div>
);
}

export default NotificationEventMap;