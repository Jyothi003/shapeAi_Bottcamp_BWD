import React from "react";

function function () {
  var curryear = new Data().getfullyear();

  return (
<footer>
  <p>copyright @ {curryear}<p/>
  </footer>
  );

}
export default footer;